/**
 * PrintConcatenation
 */
public class PrintConcatenation {

    public static void main(String[] args) {
        String foo = "foo";
        int x = 35;
        System.currentTimeMillis();
        System.exit(0);
    }
}
