public class WorkingDirectoryTest {

    public static void main(String[] args) {
        String dir = System.getProperty("user.dir");
        System.out.println(dir);
    }
}
