public interface IBreakpoints {

    public abstract void instanceMethod();
}
