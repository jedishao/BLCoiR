/**
 * This class represents an existing resource within the default java project to be used with
 * the migration delegate testing
 */
public class MigrationTests {

    public static void main(String[] args) {
    }
}
