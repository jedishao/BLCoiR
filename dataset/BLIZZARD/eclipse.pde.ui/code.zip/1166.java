public interface X {
}
