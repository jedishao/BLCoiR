/*******************************************************************************
 * Copyright (c) 2008 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package x.y.z;

import internal.x.y.z.Iinternal;
import internal.x.y.z.internal;

/**
 * 
 */
public class testMRL7 {

    public static class inner {

        public abstract static class inner2 {

            public abstract internal[] m1();

            protected abstract internal m2();
        }
    }

    public abstract static class inner2 {

        public abstract Iinternal[] m3();

        protected abstract Iinternal m4();
    }
}
