/**
 * Test unsupported @nooverride tag on an enum
 * @nooverride
 */
public enum test6 implements  {

    ;
}
