/**
 * @deprecated
 */
public class X {
}
