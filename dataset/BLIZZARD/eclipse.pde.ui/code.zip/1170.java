package a.b.c;

/**
 * 
 * @since
 */
public interface TestInterface4 {

    /**
	 * @noimplement
	 * @since
	 */
    public interface Inner1 {
    }

    /**
	 * @noimplement
	 * @since
	 */
    interface Inner2 {
    }
}
