package x.y.z;

import i.NoExtendI;

/**
 * 
 */
public interface test7 extends NoExtendI {
}
