package a9;

class B {

    private void m() {
    }
}

class A extends B {

    void m() {
    }
}

class C extends A {

    void m() {
    }
}
