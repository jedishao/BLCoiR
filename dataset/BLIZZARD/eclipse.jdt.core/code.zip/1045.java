package test0068;

public class X {

    private void foo(Class<? super Object> class1) {
    }
}
