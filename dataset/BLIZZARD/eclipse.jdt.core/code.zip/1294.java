public class X {

    /**
    * Some method.
    */
    public void someMethod(String argument1, String argument2, String argument3) {
    }
}
