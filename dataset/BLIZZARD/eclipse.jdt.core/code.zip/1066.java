public class CorrectMethod1 {

    public void bar0() {
    }

    void foo() {
        bar();
    }
}
