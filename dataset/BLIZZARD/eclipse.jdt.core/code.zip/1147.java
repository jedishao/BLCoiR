package test.test1.test2;

import java.io.*;
import java.util.Vector;

public class Test {

    public int i;

    public void foo(int k) {
        if (k > 0) {
            i = 3;
            ;
            ;
        } else if (k == 0) {
            i = 2;
        }
        if (i == 2)
            return;
        if (k > 0)
            i = 3;
    }

    public void bar() {
    }

    // long field
    public long l;

    public String s = null;
}
