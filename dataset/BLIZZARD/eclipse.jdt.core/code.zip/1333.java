package test0693;

public class Y {
}
