public class X {

    void foo() throws java.io.IOException, java.lang.IllegalArgumentException, java.lang.NullPointerException {
    }
}
