public class ResolveLocalMemberTypeDeclaration2 {

    void foo() {
        class Y {

            class Member {

                class MemberOfMember {
                }
            }
        }
    }
}
