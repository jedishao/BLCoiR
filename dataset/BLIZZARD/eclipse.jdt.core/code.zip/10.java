class Example extends AnotherClass {

    int foo() {
        int sum = 100 + 200 + 300 + 400 + 500 + 600 + 700 + 800;
        int product = 1 * 2 * 3 * 4 * 5 * 6 * 7 * 8 * 9 * 10;
        boolean val = true && false && true && false && true;
        return product / sum;
    }
}
