package test0174;

import java.util.*;

public class Test {

    int i;

    int foo() {
        i++;
        return i;
    }
}
