package test0376;

class A {

    void f() {
        A a = (A) this;
    }
}
