package test.tags.link;

public class X03a {

    /** {@inheritDoc} */
    void foo() {
    }
}
