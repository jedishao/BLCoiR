public class A {

    public static final AliasLabelType ALLOWANCE_TAB_COMMAND_DELETE = new AliasLabelType("ALLOWANCE_TAB_COMMAND_DELETE");
}
