package test0217;

import java.util.*;

public class Test {

    /* Multiple lines comment
	 */
    class B {
    }
    /**/
}
