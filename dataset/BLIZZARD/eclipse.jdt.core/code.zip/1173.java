class F {

    String s = "\n";
}
