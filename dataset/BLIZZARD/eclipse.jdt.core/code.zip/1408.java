package r7;

/* Test case for bug 37438 searchenging NPE in searchDeclarationsOfReferencedTypes */
public class A {
}
