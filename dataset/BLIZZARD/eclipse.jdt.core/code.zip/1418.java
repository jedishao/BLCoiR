package test0695;

public enum X implements  {

    ;
}
