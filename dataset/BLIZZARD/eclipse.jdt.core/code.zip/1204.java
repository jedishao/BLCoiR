public class A {

    public void testMethod() {
        for (int i = 0; i < 10; i++) {
        }
        if (true)
            System.out.println();
        while (false) {
        }
    }
}
