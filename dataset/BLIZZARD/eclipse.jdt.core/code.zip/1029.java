package test.bugs.b232788;

public class X02_spaces {
    /*
 * Spaces mode, indentation size=0
 */
}
