// test032 
public class A {

    protected synchronized Object foo() throws IOException, Exception {
        return new String("this is a very long long long long string") != null ? new Object() : null;
    }
}
