public class A {

    A foo() {
        return new A() {
        };
    }
}
