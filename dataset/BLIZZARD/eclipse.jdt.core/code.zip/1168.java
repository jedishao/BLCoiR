public class A {

    Object result = (foo == null) ? new Object[] {} : foo.toArray();
}
