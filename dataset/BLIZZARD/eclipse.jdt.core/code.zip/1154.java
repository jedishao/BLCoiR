public class FormaterBug {

    public static void main(String[] args) {
    }

    public synchronized void method1() {
    }

    public synchronized void method2() {
    }

    public synchronized void method3() {
    }

    public synchronized void method4() {
    }

    public synchronized void method5() {
    }

    public synchronized void method6() {
    }

    public synchronized void method7() {
    }
}
