public class A {

    void foo() {
        for (; ; ) ;
    }
}
