package b231263;

public class X {

    /**
	 * @param str
	 *            the string with a
	 *            description on 2
	 *            lines.
	 * 
	 * @return the return description
	 *         which is also on 2 lines
	 */
    public void foo() {
    }
}
