/*
Created on Dec 15, 2003 by jon.nall
This is some more text

and some more  
*/
class A {
}
