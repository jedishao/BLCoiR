class A {
}

class B {
}
