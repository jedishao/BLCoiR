public class X {

    public static void main(String[] args) {
        if (true)
            throw new RuntimeException("X");
        loop: System.out.println("X");
    }
}
