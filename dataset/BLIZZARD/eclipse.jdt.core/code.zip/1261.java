package test.wksp.eclipse;

public class X13 {

    /**
	 * Returns the string from the plugin's resource bundle, or 'key' if not
	 * found.
	 * 
	 * @param key
	 *            the resource string key
	 * @return the resource string for the given key
	 */
    String foo(String key) {
        return null;
    }
}
