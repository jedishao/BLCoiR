public class A {
}
