package PackageReference;

public class C extends p3.p2.p.X {
}
