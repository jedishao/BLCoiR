package test.comments.block;

interface X01 {

    /*
	 * These possibilities include: <ul> <li>Formatting of header comments.</li>
	 * <li>Formatting of Javadoc tags</li> </ul>
	 */
    int foo();
}
