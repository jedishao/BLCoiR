public class ResolveDuplicateMethodDeclaration {

    void foo() {
    }

    void foo() {
    }
}
