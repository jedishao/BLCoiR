package test0691;

public class X {

    public void foo() {
    }
}
