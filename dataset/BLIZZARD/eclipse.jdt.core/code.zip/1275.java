package test.prefs.example;

public class X05 {

    /**
  * This is just a simple example to show that comments will be formatted while processing a compilation unit only if the F_INCLUDE_COMMENT flag is set. 
  * @param str The input string
  */
    void foo(String str) {
    }
}
