// test033 
public class A {

    protected synchronized Object foo() throws IOException, Exception {
        return new String("") != null ? null : null;
    }
}
