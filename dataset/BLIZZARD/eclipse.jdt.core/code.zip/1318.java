class Example {

    void foo() {
        int k, n;
        for (int i = 0, j = 100; i < 10; i++, j--) {
        }
    }
}
