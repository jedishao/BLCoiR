public class Q {

    public  Q() {
        // code formatter formats as expected
        String a1[] = new String[] { "s" };
        // missing space before end brace
        String a2[] = new String[] { new String("s") };
    }
}
