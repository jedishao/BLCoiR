package test0345;

public @interface Test {

    String[] groups();
}
