package test0050;

public class X {

    public void foo(String[]... i[]) {
    }
}
