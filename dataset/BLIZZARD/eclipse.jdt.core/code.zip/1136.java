public class X {

    final String[] empty = new String[] {};

    public static void main(String[] args) {
    }
}
