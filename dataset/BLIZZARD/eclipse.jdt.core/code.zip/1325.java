public class FormatTest {

    private String a, b, c;

    @SuppressWarnings("unchecked")
    private Long one, two;
}
