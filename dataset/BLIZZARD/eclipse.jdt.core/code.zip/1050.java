public class A {

    int Example(boolean Argument) {
        return argument ? 100000 : 200000;
    }
}
