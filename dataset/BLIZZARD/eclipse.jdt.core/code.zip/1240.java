package ObjectMemberTypeReference;

public class A {

    class Object {
    }

    public void foo() {
        new Object();
    }
}
