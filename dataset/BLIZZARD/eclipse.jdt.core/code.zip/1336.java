public class A {

    void foo() {
        do ; while (true);
    }
}
