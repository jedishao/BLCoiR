package test0397;

public class A {

    public void foo() {
        int i = (1 + 2) * 3;
    }
}
