package s2;

import static s2.pack.age.S.M;

public class D {

    public void foo() {
        M m = new M();
        m.in();
    }
}
