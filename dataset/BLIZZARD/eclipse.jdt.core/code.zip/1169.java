public class A {

     A() {
    }

    void foo() {
    }
}
