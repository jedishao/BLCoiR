package test0570;

public class A {

    public String m(String s) {
        return s + "a" + "abc" + "e" + ("i" + ("i" + "ib2") + "i2") + "c";
    }
}
