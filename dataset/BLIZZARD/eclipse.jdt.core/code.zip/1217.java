/*
 * test
 * 003 
 */
package p1.p2.test;

import java.io.Serializable;
import java.io.IOException;

public abstract class A extends java.lang.Object implements Runnable, Cloneable, Serializable {
    /*
	 * test4
	 * 004 
	 */
}
