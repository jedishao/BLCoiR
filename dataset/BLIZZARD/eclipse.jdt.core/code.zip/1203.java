public class A {

    MyLongClassName myLongVariable = someOtherLongCode(param1, param2, param3);
}
