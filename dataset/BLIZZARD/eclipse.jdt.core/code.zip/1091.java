package s2;

/* Test case for bug 3230 Search - Too many type references for query ending with * (1GAZVGI) */
public class Z {

    X f[];
}
