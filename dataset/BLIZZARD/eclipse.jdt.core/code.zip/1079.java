public class Bug49361 {

    public static void main(String[] args) {
        int[] table = new int[] { 1, 2, 3 };
        int[] empty = new int[] {};
    }
}
