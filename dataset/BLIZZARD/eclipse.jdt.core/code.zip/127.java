package p3;

/* Test case for bug 23644 hierarchy: getAllSuperTypes does not include all superinterfaces?  */
public interface I1 {
}
