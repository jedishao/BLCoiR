package test0604;

public class X {

    java.lang.String fa;

    java.lang.String[] fb;

    java.lang.String[][] fc;

    java.lang.String[][][] fd;

    void foo() {
        java.lang.String a;
        java.lang.String[] b;
        java.lang.String[][] c;
        java.lang.String[][][] d;
    }
}
