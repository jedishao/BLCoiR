public class ResolveDuplicateMethodDeclaration7 {

    class Inner {

        void foo(Zork o) {
        }

        void foo(Zork o) {
        }
    }
}
