package p;

public class External {

    public Object field;
}
