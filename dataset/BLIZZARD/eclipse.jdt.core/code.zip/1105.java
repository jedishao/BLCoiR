public class MikeClassTest2 {

    //mike	test		2342323
    public static int bob = 3;

    public static int mike = 3;
    /*my	comments		tabbed*/
}
