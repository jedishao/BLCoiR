package test1;

public class E {

    public void foo() {
        goo();
        System.out.println();
    }
}
