package test.comments.block;

public class X05d {
    /*
	 * 3. "This product includes software developed by the Apache Software
	 * Foundation (http://www.apache.org/)." Alternately, this acknowledgment
	 * may appear in the software itself, if and wherever such third-party
	 * acknowledgments normally appear.
	 */
}
