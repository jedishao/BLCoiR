package test0439;

public class E extends C {

    public void foo() {
        CInner c = null;
    }
}
