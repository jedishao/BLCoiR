package test.prefs.example;

public class X14a {

    /**
	 * Tests a new (<code>DiffNode</code>) code syntax
	 * 
	 * @param kind
	 * of difference (defined in <code>Differencer</code>)
	 */
    public void foo() {
    }
}
