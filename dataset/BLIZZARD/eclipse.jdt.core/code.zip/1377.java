package test0071;

public class X {

    <E extends Object> void m(E e) {
    }
}
