// test017
public class A {

    String s2;

    // toto
    Object oooooooooooooooooooooooooooooooo = null, sssssssssssssssssssssssssssssssssssss;

    // test 
    int iiiiiiiiiiiiiiiiiiiii = 1, jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj = 2, kkkkkkkkkkkkk;

    String s;
}
