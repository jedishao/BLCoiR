package deprecation;

/**
 * @deprecated
 */
public class Bug127628Type2 {

    public class Bug127628TypeInner2 {
    }
}
