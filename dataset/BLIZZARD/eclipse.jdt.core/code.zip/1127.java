class Example {

    void foo() {
        for (int i = 0, j = 100; i < 10; i++, j--) {
        }
    }
}
