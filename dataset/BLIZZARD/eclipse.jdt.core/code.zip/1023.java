package test1;

public class A {

    public void foo() {
        for (int i = 0; i < 8; i++) {
            foo();
        }
    }
}
