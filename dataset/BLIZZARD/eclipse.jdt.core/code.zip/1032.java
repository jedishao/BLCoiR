package a.b;

public class ImportedClass {
}
