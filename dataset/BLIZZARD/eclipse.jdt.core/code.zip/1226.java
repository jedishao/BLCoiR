package javadoc.testBug53276;

/**
 * It removes the file from both the entries of the parent-folder
 * and from the local filesystem.
 */
public class TestB {
}
