public class CompletionDefaultPackage {

    public void foo() {
        Default.foo();
    }
}
