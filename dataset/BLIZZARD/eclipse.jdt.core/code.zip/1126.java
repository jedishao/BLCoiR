import java.awt.*;

public class FormatTest {

    /************************************
	* method_one
	* 
	* 		nothing special.
	************************************/
    public void method_one() {
        int i = 1;
        int j = 2;
        for (i = 12; i < 100; i++) {
            if (i % 2 == 0)
                System.out.println("xx");
            else
                System.out.println("yy");
            j = 0;
        }
    }
    // method_one
}
// class FormatTest
