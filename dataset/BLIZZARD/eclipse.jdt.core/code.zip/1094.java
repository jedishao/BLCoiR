interface StuffInterface {

    Integer getStuff(int someValue);

    int sendStuff(int otherValues);
}
