package test.wksp.junit;

/**
 * <p>
 * The list of excluded package paths is specified in a properties file
 * "excluded.properties" that is located in the same place as the
 * TestCaseClassLoader class.
 */
public class X01 {
}
