package p2;

public interface I1 extends I {
}
