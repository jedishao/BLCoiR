public class X03 {

    /**
	 **
	 ** Returns true if the operator
	 * expects...
	 **/
    void foo() {
    }
}
