public class CompletionExactNameCaseInsensitive {

    void foo(compleTionexactnamecaseInsensitive c) {
    }
}

class CompletionExactNameCaseInsensitivePlus {
}
