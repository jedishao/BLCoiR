package q8;

public class X210070 {

    public String foo() {
        return "abc";
    }
}
