package test0246;

import java.util.*;
import java.io.IOException;

public class Test {
}
