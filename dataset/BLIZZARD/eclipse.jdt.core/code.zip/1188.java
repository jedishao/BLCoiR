package test0013;

class Test0013 {
}

public class Test {

    class Inner {

        <Test0013> void foo() {
        }
    }
}
