package test1;

import java.util.Vector;

public class A {

    public void foo() {
        Runnable runnable = new Runnable() {
        };
        runnable.toString();
    }
}
