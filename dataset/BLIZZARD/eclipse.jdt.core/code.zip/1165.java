/**
 * This is a sample class, to demonstrate the problems
 * with the Eclipse formatter.
 * @author Adalbert Homa
 * @version 1.0
 */
public class FormatTest2 {

    public void testMethod() {
        for (int i = 0; i < 10; i++) {
            // Next line show the problem
            AccountAccessGroupBean aags = new AccountAccessGroupBean(// groupId
            "a", // groupName 
            "b", // lastModified
            "c", // modifiedFlag
            "d");
            // The second line is without end of line comments
            AccountAccessGroupBean b = new AccountAccessGroupBean("a", "b", "c", "d");
        }
    }

    private static class AccountAccessGroupBean {

         AccountAccessGroupBean(String a, String b, String c, String d) {
        }
    }
}
