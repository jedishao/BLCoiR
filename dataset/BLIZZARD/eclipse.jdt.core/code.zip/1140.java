package wc;

public class X {
}
