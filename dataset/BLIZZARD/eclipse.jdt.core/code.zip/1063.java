class emptyClass {
}

enum MyEnum implements  {

    UNDEFINED(0) {
    }
    ;
}

enum EmptyEnum implements  {

    ;
}
