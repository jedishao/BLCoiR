import java.util.List;
import java.io.IOException;

public class X {

    List list;

    void foo() throws IOException {
    }

    public static void main(String[] args) {
    // TODO Auto-generated method stub
    }
}
