package test0511;

public class A {

    public void foo() {
        new Y();
    }
}
