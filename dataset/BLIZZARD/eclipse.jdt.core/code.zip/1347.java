public interface A extends Comparable<Class<?>> {
}
