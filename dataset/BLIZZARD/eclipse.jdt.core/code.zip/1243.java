package c8;

/* Test case for bug 23112 search: need a way to search for references to the implicit non-arg constructor */
public class X {
}
