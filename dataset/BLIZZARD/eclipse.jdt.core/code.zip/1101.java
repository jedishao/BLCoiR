package p10.a.b.om;

import java.util.Vector;

public class X {

    public static final class AncestorEnumeration extends Vector {
    }
}
