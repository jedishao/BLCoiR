package test0324;

public class Test {

    void foo() {
        Object x;
        x = (java.lang.Object[]) null;
    }
}
