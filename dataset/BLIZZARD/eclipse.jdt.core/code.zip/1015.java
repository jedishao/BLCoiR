package test0002;

public @interface X {

    String first();

    String last();
}
