package test0518;

import java.util.*;

public class Test {

    /**
	 * Javadoc
	 */
    static {
        /* */
        // line comment
        System.out.println("Hello" + " world");
    }
}
