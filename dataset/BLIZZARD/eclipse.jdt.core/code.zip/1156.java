package test.prefs.example;

public class X14 {

    /**
	 * @param kind
	 *            of difference (defined in <code>Differencer</code>)
	 */
    public void foo() {
    }
}
