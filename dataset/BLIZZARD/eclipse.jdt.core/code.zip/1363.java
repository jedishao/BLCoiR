// test034 
public class A {

    void foo() {
        if ((condition1 && condition2) && (condition3 && condition4) || (condition5 && conditionnnnnnnnn6)) {
            doSomething();
        }
    }
}
