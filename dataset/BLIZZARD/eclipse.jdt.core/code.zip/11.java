public class ResolveQualifiedName5 {

    public class XX {

        public class YY {

            public class ZZ {
            }
        }

        YY.ZZ zz;
    }
}
