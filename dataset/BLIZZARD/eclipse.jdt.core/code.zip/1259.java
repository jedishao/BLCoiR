package test0248;

import java.util.*;

public class Test {

    native void m(int i);
}
