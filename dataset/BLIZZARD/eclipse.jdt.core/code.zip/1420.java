// test013
package p1.p2.test;

import java.io.Serializable;
import java.io.IOException;

public abstract class A implements /*  */
Serializable, Toto, Titi, Tata {

    // boolean 
    boolean value = /* */
    true;

    // test 
    Object s = null;

    protected synchronized void foo(final java.lang.String s1, long l, final java.lang.String s2, int a, long b) throws IOException, Exception {
    }

    public  A(int i) throws IOException, Exception {
        int i = 0;
        i = 2;
        ;
        ;
    }
}
