package test0555;

public class A {

    //$NON-NLS-1$
    public static final String BUNDLE_NAME = "test.test";

    public static String getString(String s) {
        return "";
    }
}
