public class X {

    @Deprecated
    @SuppressWarnings("unused")
    public void setFoo(@Required String name, @NotNull int value, @Required int start, @Required int length) {
    }
}
