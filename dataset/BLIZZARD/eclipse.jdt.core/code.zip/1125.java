package test0147;

import java.util.*;

public class Test {

    /** JavaDoc Comment*/
    static {
    }
}
