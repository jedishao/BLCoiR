package test0084;

public class X {

    Integer a;

    int b;
}
