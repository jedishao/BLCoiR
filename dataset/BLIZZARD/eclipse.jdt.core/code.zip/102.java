package test0690;

public class X {
}
