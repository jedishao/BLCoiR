public class A {

    int i = 1;
}
