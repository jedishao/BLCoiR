class Example {

    void bar() {
    }

    void foo() {
        for (bar(), bar(); i < 10; i++, j--) {
        }
    }
}
