package PackageReference;

public class NoReferenceF {

    p3.X foo() {
        return null;
    }
}
