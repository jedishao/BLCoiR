public class A {

    void foo(String title, Object test) {
        //$NON-NLS-1$
        System.out.println(title + " world");
        System.out.println(test.toString());
    }
}
