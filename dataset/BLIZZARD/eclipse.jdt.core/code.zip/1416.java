import p1.*;

public class ResolveClass4 {

    public X foo() {
        return null;
    }
}
