package test0155;

import java.util.*;

public class Test {

    public void m(int i, final boolean b) {
    }
}
