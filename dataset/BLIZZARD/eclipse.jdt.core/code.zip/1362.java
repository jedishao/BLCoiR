public class A {

    void thisIsAMethodWithAVeryLongName(long l, int i, String s, Object o) throws IOException {
    }
}
