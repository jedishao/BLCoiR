package test.tags.others;

/**
 * @author Zhao
 *
 * TODO To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Style - Code Templates
 */
public class X02 {
}
