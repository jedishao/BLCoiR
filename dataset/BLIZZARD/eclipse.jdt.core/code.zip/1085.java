package test.wksp.eclipse;

public class X28 {

    /**
	 * Shutdown the HCR mgr and the Java debug targets.
	 * 
	 * @see org.osgi.framework.BundleActivator#stop(org.osgi.framework.BundlContext)@see
	 *      org.eclipse.core.runtime.Plugin#shutdown()
	 */
    public void foo() {
    }
}
