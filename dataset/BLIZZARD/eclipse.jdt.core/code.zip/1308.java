package p;

public class Bug336046 {

    public void foo() {
    }
}
