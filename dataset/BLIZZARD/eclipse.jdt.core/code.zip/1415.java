/**		
 * test007		
 *		
 */
package /* test2 */
p1.p2.test/* */
;

import java.io.Serializable;
import java.io.IOException;

/**		
 * Class javadoc comment		
 */
public abstract class A extends /* */
java.lang.Object implements Runnable, Cloneable, Serializable {
}
