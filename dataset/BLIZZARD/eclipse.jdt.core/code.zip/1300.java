package j4;

public class MF47209 {

    /**
	 * @see MF47209#m47209(int)
	 */
    public int f47209;

    public  MF47209(String str) {
    }

    public void m47209(int x) {
    }
}
