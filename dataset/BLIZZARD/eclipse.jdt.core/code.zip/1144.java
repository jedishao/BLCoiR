package test.comments.block;

/**
 * Base class for all test runners. This class was born live on stage in
 * Sardinia during XP2000.
 */
public abstract class X06 {

    /*
	 * Simple text
	 */
    void foo() {
    }
}
