package test0040;

public class X {

    <T> T foo() {
        return null;
    }
}
