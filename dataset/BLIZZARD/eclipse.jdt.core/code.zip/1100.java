public class X01 {

    /**
	 * Test generic param reference
	 * 
	 * @param <T>
	 *            type parameter
	 * @param str
	 *            the string argument
	 */
    <T> void foo(String str) {
    }
}
