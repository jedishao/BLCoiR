public class ThisIsAClassWithALongName implements Interface1, Cloneable, Serializable {
}
