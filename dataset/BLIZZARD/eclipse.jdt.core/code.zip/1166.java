package VariousTypeReferences;

public class B {

    void foo(A a) {
    }
}
