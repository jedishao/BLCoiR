package b123679.pack;

public interface I123679 {
}
