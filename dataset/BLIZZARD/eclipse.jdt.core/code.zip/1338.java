package test0041;

import java.util.*;

public class Test {

    public static void main(String[] args) {
        Class c = long.class;
    }
}
