public class X {

    int x(@Marker int p) {
        return 10;
    }

    ;

    Zork z;
}

@java.lang.annotation.Target(java.lang.annotation.ElementType.TYPE_PARAMETER)
@interface Marker {
}
