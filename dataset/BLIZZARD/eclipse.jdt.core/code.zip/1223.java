public enum X implements  {

    CONST1() {
    }
    , CONST2() {
    }
    , CONST3() {
    }
    , CONST4() {
    }
    , CONST5() {
    }
    , CONST6() {
    }
    , CONST7() {
    }
    , CONST8() {
    }
    ;

    int constant = 4;

    public static void main(String[] args) {
    }
}
