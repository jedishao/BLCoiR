class A {

    int[] tab = new int[] {};
}
