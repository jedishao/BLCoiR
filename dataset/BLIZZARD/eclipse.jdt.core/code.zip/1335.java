package test.html.others;

public interface X07 {

    /**
	 * 																		   <li> 				
	 * 
	 * this 	might include or li tags that might be located right on the margin         
	 * 
	 * 																		   </li>			  
	 * 
	 * 
	 */
    int foo();
}
