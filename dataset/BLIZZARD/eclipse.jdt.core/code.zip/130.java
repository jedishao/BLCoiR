package javadoc.testBug68017;

public class TestWarn2 {

    /**
	 *	@return#
	 */
    public int foo() {
        return 0;
    }
}
