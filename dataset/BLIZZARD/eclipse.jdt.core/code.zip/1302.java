// test006 
package p1.p2.test;

import java.io.Serializable;
import java.io.IOException;

public abstract class A implements /*                                                                                  */
Runnable {

    public abstract class B implements /*                                                                                  */
    Runnable {
    }
    /*            last comment: end of member class A */
}
/*            last comment: end of class A */
