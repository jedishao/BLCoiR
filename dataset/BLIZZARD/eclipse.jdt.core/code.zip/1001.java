public class X extends Y<@Marker Integer, String> {
}

class Y<T, V> {

    Zork z;
}
