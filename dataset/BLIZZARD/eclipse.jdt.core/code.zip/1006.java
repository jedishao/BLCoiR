/**
 * Test
 *
 */
package /* test2 */
p1.p2.test/* */
;

import java.io.Serializable;
import java.io.IOException;

/* */
class A extends java.lang.Object implements Runnable, Cloneable, Serializable {

    public void run() {
    }

    public static void foo() throws IOException {
    }
}
