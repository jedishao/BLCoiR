public class X {

    X x = new @Marker X();

    X y = new <String> @Marker X();
}
