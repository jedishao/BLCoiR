package p;

/*
 * A very important comment.    
 */
class Secondary {
}
