//8, 17, 8, 22
package p;

public class A {

    void m() {
        int x = 9;
        int y = 10;
        int k = 8;
        int j = x + y + 30 + k + x + y + k + k + 40 + x + y + k + y + x;
    }
}
