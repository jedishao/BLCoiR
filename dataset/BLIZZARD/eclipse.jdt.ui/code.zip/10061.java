package p;

public interface Foo {

    default void d() {
    }
}
