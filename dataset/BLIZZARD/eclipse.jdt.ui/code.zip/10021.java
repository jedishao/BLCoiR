// 5, 36 -> 5, 36  replaceAll == true, removeDeclaration == false
package p;

class Klus {

    private static final int KLUSPLATZ = 34;

    private int kreuzplatz = (kreuzplatz = -1 + KLUSPLATZ + (-1));
}
