package p;

class A {

    void m() {
        int i = 1 + 1;
    }
}
