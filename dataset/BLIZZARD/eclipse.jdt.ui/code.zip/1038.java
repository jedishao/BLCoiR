package return_out;

import java.util.List;

public class A_test712 {

    public List foo() {
        return extracted();
    }

    protected List extracted() {
        /*[*/
        return /*]*/
        null;
    }
}
