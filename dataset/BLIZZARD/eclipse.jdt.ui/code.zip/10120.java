package p;

public class SomeClass2 {

    static SomeClass2 someClass2;

    static SomeClass2 fsSomeClass2;

    static SomeClass2 fsSomeClass2_suffix;

    static SomeClass2 someClass2_suffix;
}

;
