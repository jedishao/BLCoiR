package receiver_out;

public class TestThisReceiver {

    private Object data;

    private void use(Object data) {
        this.data = data;
    }
}
