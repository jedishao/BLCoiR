//renaming A.m to fred
package p;

public class A {

    int fred(int m) {
        return fred(m);
    }
}

class B {

    void k() {
        A a = new A();
        a.fred(a.fred(6));
    }
}
