package p;

class A {

    static int i;

    class Inner {

        void f() {
            i = 1;
        }
    }
}
