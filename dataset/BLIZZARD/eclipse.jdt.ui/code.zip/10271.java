package base_in;

public class TestFinal {

    final int field = 0;

    public void foo() {
        int i = field;
    }
}
