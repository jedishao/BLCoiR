package p;

abstract class A {
}
