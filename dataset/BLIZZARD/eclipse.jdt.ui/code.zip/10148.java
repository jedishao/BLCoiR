package p;

public class B {

    int field = 0;
}
