package p;

class A {
}

class B extends A {

    public int f;
}
