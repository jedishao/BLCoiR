package p;

public interface Foo {

    static void s() {
    }

    /**
	 * 
	 */
    static void s() {
        Foo.s();
    }
}
