package locals_in;

public class A_test551 {

    public void foo() {
        int i = 0;
        do {
            /*[*/
            /*]*/
            i++;
        } while (true);
    }
}
