import java.util.*;
import java.io.File;

public class Blinky {

    public static void main(String[] args) {
    }
}
