package p0;

public class Bar {

    /**
	 * @param foo
	 */
    public static void bar(Foo foo) {
        foo.bar();
    }
}
