package r;

public class B {

    public static void n() {
    }
}
