//renaming A.m to k 
package p;

class A {

    public void m() {
    }
}

class AQE extends A {

    public void m() {
        super.m();
    }
}
