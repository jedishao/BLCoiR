package r.p1;

class A {
}
