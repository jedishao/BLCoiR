//6, 12, 6, 12
package p;

class A<T> {

    void m(T arg) {
        T myT = arg;
    }
}
