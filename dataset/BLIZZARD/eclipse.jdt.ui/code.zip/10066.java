package p;

/** typecomment template*/
interface I {

    int X = 0;
}
