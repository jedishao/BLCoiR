package p;

abstract class A {
}

abstract class B extends A {

    public abstract void f();
}
