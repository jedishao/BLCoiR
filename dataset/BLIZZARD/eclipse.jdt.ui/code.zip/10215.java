public class B {

    public void foo() {
        A a = null;
        a.bar();
    }
}
