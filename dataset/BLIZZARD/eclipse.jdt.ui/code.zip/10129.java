package p;

public class Bar {

    void bar() {
    }

    void foo() {
        bar();
    }
}
