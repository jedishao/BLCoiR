//6, 32, 6, 44
package p;

import java.util.function.Consumer;

public class A {

    Consumer<Integer> a1 =  x -> {
        String string = x.toString();
    };
}
