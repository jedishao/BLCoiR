package object_in;

public enum TestEnumReadWrite implements  {

    TEST() {
    }
    ;

    public String field;

    public void foo() {
        field = field + "field";
    }
}
