//add boolean e before d
package p;

class A {

    public void m(Object[] b, int c, boolean d) {
        m(new Object[] {}, Integer.MAX_VALUE, false);
    }
}
