package p;

class A {

    private A f(A a0, Object a1) {
        return null;
    }
}

class B extends A {

    private A f(A a3, Object a4) {
        return null;
    }
}
