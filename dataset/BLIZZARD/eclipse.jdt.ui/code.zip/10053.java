package p;

class A {

    static final Short C = 1;

    boolean b = equals(C);
}
