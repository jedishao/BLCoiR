package p;

public class A {

    public int test = 0;

    public static void main(String[] args) {
        A test = new A();
        test.test = 1;
    }
}
