package p;

class A {

    static int F = 1;
}
