package p;

class A {

    static {
    }
}
