package p;

class A {

    void f2() {
    }

    /***/
    void f1() {
    }
}
