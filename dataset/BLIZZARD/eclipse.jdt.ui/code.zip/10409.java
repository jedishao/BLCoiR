package p;

import p.Outer.Inner;

public class B {

    public void foo() {
        Inner<String> i;
    }
}
