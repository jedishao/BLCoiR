package invalidSelection;

public class A_test172 {

    public void foo() {
        /*]*/
        int /*[*/
        i = 10, j = 20;
    }
}
