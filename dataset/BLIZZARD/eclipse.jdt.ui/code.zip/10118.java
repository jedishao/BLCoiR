package p;

public class A {

    public int amount() {
        return 1;
    }

    public void add() {
    }
}
