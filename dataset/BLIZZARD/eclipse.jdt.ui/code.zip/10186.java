package p;

class A {

    int m(int i) {
        return 0;
    }
}
