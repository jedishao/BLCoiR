package p;

class A {

    int f;

    public static int g;
}
