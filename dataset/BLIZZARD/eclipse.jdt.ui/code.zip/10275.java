package p;

class A<T> {

    private T f;

    void m() {
        T g = f;
    }
}
