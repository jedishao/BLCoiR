package p;

public class SomeOtherClass {

    SomeOtherClass someOtherClass;

    /**
	 * @return Returns the someOtherClass.
	 */
    public SomeOtherClass getSomeOtherClass() {
        return someOtherClass;
    }

    /**
	 * @param someOtherClass The someOtherClass to set.
	 */
    public void setSomeOtherClass(SomeOtherClass someOtherClass) {
        this.someOtherClass = someOtherClass;
    }
}
