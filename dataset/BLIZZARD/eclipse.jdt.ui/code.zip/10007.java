package p;

class T {

    int r() {
        return 4;
    }

    void f() {
        r();
    }
}
