//not on interfaces
package p;

interface A {

    void m(int /*[*/
    i, /*]*/
    int j);
}
