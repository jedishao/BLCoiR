import java.util.Hashtable;

class A_testInvalidSelection_in {

    public static void main(String[] args) {
        Hashtable h = new Hashtable();
        System.out.println("Hello, world!");
    }
}
