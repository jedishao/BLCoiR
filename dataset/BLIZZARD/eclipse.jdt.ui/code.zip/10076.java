// 10, 37 -> 10, 43
package p;

class A {

    private static final int CONSTANT = 2 + 2 * 4;

    void foob() {
        int c = 3 * (2 + 1) + CONSTANT + 28;
        int e = (2 + 2) * (27 + 2 * (CONSTANT + 1 * 2));
    }
}
