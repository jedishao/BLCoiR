package p1;

import p2.C;
import java.util.*;

public class B extends C {
}
