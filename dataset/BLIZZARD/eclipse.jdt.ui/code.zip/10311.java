//assigned to more than once
package p;

class A {

    int m(int y) {
        /*[*/
        int /*]*/
        i = 0;
        return y + (i--);
    }

    ;
}
