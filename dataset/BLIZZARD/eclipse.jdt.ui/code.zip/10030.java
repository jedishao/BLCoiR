package p;

class A {

    int m(int y) {
        {
            int x = 1 + 2;
        }
        return 1 + 2;
    }
}
