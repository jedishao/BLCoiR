package p;

class A<T> {
}

class B extends A<String> {

    public void m() {
    }
}
