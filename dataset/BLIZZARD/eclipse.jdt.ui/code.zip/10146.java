package p;

public class A implements OldInterface {

    public int amount() {
        return 1;
    }
}
