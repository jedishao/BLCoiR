package validSelection;

public class A_test230 {

    public void foo() {
        /*[*/
        {
            foo();
        /*]*/
        }
    }
}
