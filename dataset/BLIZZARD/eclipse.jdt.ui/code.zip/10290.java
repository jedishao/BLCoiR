package p;

public class B {

    private static class InnerTarget {
    }
}
