package p;

class A {

    void i() {
        // blah
        String test = "";
        System.out.println(test);
    }
}
