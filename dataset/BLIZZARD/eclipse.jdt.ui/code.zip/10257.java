package p;

class A {

    static void m() {
    }
}
