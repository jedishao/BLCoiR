package p;

interface A extends I {
}
