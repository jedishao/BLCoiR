//8, 16 -> 8, 22   AllowLoadtime == false
package p;

class S {

    static int s;

    int f() {
        return 23 * s;
    }
}
