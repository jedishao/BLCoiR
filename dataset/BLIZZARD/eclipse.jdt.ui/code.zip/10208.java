package p;

class A {

    private void m() {
        m();
    }
}
