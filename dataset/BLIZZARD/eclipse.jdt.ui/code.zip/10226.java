package tests;

public class QualifiedTests {

    static {
        p.p.ATest aQualifiedTest;
        p.p.A aQualified;
    }

    static {
        p.p.ATest aQualifiedTest;
        p.p.A aQualified;
    }
}
