package validSelection;

public class A_test232 {

    public void foo() {
        /*]*/
        {
            foo();
        /*[*/
        }
    }
}
