package p.p;

import static q.A.CONST;

public class ATest {

    int C = CONST;
}
