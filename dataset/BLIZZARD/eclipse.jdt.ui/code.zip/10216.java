package p;

import java.util.*;

class A {

    void foo() {
    }

    int bar;

    int baz;
}
