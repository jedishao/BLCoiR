package p;

class A {

    public void m() {
    }

    public void m1() {
    }

    void f(A a) {
        a.m();
    }
}
