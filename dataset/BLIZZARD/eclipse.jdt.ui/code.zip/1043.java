package p;

class A {

    void f1(int i) {
        switch(i) {
            case 1:
                break;
            default:
                break;
        }
    }
}
