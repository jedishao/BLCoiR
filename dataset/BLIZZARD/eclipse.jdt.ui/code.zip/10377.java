package p;

/** typecomment template*/
public interface I {

    void m2();
}
