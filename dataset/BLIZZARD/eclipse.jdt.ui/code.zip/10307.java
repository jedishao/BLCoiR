package p;

class A {

    static class Inner2 {

        static class Inner2Inner {
        }
    }
}
