//renaming A.m to fred
package p;

public class A {

    private void m() {
    }

    void k() {
        A a = new A();
        a.m();
    }
}
