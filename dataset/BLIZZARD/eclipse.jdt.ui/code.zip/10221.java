// 3, 33 -> 3, 40  removeDeclaration == false, replaceAll == true
class C {

    public static final boolean I_EXIST = true;

    static {
        boolean beans = true;
    }
}

class D {

    int object_oriented_programming() {
        return false || (!false && true && (false != true));
    }
}

class CPlusPlus extends C {

    public static final int JAVA = true ? 0xCAFEBABE : OxO;

    void beans() {
        System.err.println(true);
    }
}
