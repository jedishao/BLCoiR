package p;

public class A {

    String X = B.TAG1, Y = B.TAG2;
}
