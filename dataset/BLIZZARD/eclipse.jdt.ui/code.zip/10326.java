package p;

public class A {

    static String foo;
}
