package p;

interface A {

    int[] m()[];
}

class B implements A {

    public int[] m()[] {
        return null;
    }
}
