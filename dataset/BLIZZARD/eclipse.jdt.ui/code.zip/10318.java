package p;

abstract class A implements I {

    public abstract void m();
}
