package p;

class A {

    void f() {
        Object i = null;
    }
}
