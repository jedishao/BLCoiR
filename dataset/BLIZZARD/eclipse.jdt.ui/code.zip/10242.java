package destination_in;

public class A_test1057 {

    public static class Inner {

        public void extracted() {
        }

        public int foo() {
            return A_test1057.extracted();
        }
    }

    protected static int extracted() {
        /*[*/
        return /*]*/
        2 + 3;
    }
}
