package p1;

import p2.A;
import p2.C;

public class B {

    C c;

    p2.A p1A;

    p2.C m(C C, A A) {
        return C;
    }
}
