package p;

class A implements I {

    static I getA() {
        return null;
    }

    public void m() {
    }

    public void m1() {
    }
}
