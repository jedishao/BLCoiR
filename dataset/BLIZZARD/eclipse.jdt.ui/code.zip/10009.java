package p;

class B {

    public static final int i = 0;
}
