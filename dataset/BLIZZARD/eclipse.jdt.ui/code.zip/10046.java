package p;

/** typecomment template*/
interface I {

    void m();
}
