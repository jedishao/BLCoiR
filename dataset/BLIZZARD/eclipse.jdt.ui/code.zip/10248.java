package p;

public class B {
}
