import java.util.*;

class A_testFieldDecl_in {

    void foo() {
        list = new ArrayList();
        List list2 = list;
    }

    public static AbstractList list;
}
