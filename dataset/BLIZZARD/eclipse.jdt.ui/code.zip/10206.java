package p;

public class SomeOtherClass {

    SomeClass fSomeClass;

    /**
	 * @return Returns the someClass.
	 */
    public SomeClass getSomeClass() {
        return fSomeClass;
    }

    /**
	 * @param a The a to set.
	 */
    public void setSomeClass(SomeClass a) {
        fSomeClass = a;
    }
}
