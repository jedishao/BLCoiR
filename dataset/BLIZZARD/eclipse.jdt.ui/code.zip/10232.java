package p;

import java.util.Vector;

class A {

    public static boolean textContains(String text, Vector v) {
        return v.contains(text);
    }
}
