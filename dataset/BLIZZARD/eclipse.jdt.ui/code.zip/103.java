package validSelection_in;

public class A_test371 {

    protected void foo() {
        /*[*/
        /// comment
        foo();
        // comment
        /*]*/
        foo();
    // comment
    }
}
