class A {

    /**
	 * TestPattern
	 * 	 TestPattern
	 */
    void f() {
    }

    /*
	 * TestPattern
	 * 
	 * 	TestPattern
	 */
    void f1() {
        //TestPattern //org.eclipse.TestPattern
        f1();
        String g = "TestPattern";
        String g2 = "org.eclipse.TestPattern";
    }
}
