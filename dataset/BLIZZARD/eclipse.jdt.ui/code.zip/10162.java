package p;

class A {

    private int f;

    void m() {
        f++;
    }
}
