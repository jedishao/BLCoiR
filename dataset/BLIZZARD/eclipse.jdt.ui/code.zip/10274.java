package p;

class A {

    int f;

    void m(int i) {
        int temp = f;
        int x = temp;
    }
}
