package p;

import java.util.List;

class A {

    private void m(int i, String j) {
        List l;
    }
}
