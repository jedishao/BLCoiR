package p;

class A<T> {
}

class B<T> extends A<T> {

    public int f;
}
