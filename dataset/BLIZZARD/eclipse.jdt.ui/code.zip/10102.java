package p;

class A {
}
