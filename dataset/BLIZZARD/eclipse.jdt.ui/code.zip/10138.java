package p;

class A {

    private int i = 0;

    void f() {
        int j = 0;
    }
}
