package p;

public class A {

    public static int f;

    public void n() {
        f = 0;
    }
}
