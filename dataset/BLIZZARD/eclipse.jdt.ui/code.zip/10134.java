package my.pack;

public class C {
    /*
my.pack
my.pack.subpack
my.pack2
my.pack2.subpack
not.my.pack.subpack
notmy.pack.subpack
notmy.pack2.subpack
My.pack
*/
}
