//renaming to: j, i, k
package p;

class A {

    int l;

    int m() {
        int j = 0;
        int i = 0;
        int k = 0;
        int m = 0;
        return j + i + k + l + m;
    }

    ;
}
