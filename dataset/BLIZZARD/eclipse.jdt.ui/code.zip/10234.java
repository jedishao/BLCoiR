package p;

class A {

    void someMethod() {
        double[] doubleDim[];
    }
}
