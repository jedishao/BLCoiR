package p;

class A {

    void f() {
        String y = ("xx");
    }
}
