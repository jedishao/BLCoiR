package p;

class B extends A {

    protected void m() {
    }
}
