package p1;

public interface P {
}
