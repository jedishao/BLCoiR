package p;

//renaming A.m to k
class A {

    private int m(int m) {
        return m(m(m));
    }
}
