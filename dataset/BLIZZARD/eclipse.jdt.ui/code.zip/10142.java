package cast_out;

public class TestReturnValue5 {

    Integer foo() {
        return 1 + 1;
    }

    void x() {
        Integer a = 1 + 1;
    }
}
