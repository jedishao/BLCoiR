package p;

public class A {

    static void foo() {
    }

    ;

    static int fred;

    static class Stat {
    }
}
