package static_out;

public class TestStaticImportNone {

    private static final int x = 0;

    public static int getX() {
        return x;
    }
}
