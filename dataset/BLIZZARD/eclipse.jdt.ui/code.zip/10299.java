package p;

class A {

    int m() {
        int temp = 1 + 2;
        for (int i = 0; i == 0; ) {
            int x = temp;
        }
        return temp;
    }
}
