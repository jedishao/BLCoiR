package expression_out;

public class TestReturnStatement {

    public int main() {
        if (true) {
            return 10;
        }
        return 20;
    }

    public int foo() {
        if (true) {
            return 10;
        }
        return 20;
    }
}
