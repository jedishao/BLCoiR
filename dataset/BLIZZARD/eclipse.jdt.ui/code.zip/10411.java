//8, 16 -> 8, 19  replaceAll == true, removeDeclaration == false
package p;

import static q.Consts.III;

class A {

    int getIII() {
        return III;
    }
}
