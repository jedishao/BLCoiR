package p0;

public class Test {

    void m() {
        new StringBuffer("hello").substring(1, 3);
        new StringBuffer("hello").substring(1, 4);
    }
}
