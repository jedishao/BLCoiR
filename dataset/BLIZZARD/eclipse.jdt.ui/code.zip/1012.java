package p;

class A {

    static int x() {
    }

    ;
}

class B {

    class C extends A {
    }
}
