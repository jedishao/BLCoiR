//change to j k i
package p;

class A {

    private void m(int i, int j, int k) {
    }

    private void foo() {
        m(1, 2, 3);
    }
}
