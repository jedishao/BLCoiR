//renaming to: j, i
package p;

class A {

    int j;

    int m(final int j, int i) {
        return j + i;
    }

    ;
}
