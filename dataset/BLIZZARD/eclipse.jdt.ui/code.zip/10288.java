package p;

class A {

    void f() {
        int temp = 0 + 0;
        try {
            int j = temp;
        } finally {
            int j = temp;
        }
    }
}
