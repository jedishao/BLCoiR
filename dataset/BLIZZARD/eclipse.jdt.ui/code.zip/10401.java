package p;

import java.util.ArrayList;

public class A {

    public static final A FOO = new A() {

        ArrayList a;
    };
}
