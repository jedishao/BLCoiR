package p;

public class SomeClass2 {

    SomeClass2 someClass2;

    /**
	 * @return Returns the someClass.
	 */
    public SomeClass2 getSomeClass2() {
        return someClass2;
    }

    /**
	 * @param a The a to set.
	 */
    public void setSomeClass2(SomeClass2 a) {
        this.someClass2 = a;
    }
}
