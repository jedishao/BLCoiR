package p;

class B {

    B a;
}

;
