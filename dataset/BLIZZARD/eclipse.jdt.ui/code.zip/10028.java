package p;

interface Inner {

    int I = A.i;
}
