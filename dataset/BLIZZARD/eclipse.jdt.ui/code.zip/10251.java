package p;

public abstract class A {

    public abstract void x();

    //	 TestRunListener implementation
    public abstract void y();

    public abstract // xx
    void z();

    /** Javadoc*/
    public abstract void a();

    /**JD*/
    //abstract
    public abstract void b();

    //destruct
    public abstract void c();

    //post
    public abstract void d();
}
