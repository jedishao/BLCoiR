package p;

class Secondary {
}
