package invalidSelection;

public class A_test124 {

    Object temp;

    public void foo() {
        /*]*/
        this.temp = null;
    }
}
