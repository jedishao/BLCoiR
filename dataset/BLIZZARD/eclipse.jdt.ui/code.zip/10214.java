package my.pack;

import my.pack.C;

public class C {
}
