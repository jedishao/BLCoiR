package p;

class A {

    int x;

    protected void m() {
        this.x++;
    }
}

class B extends A {
}
