package call_in;

public class TestExpressionStatement {

    public void main() {
        /*]*/
        /*[*/
        foo();
    }

    public void foo() {
        System.out.println("Eclipse");
    }
}
