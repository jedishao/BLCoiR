package p2;

import p3.C;

public class B {

    public static final int ZEMENT = 4 * C.BEGRIFF + p3.C.BEGRIFF;
}
