// 8, 52 -> 8, 62  replaceAll == false
package p;

class PartOfReferenceSelected {

    static final String VISUALAGE_FOR_COBOL = "simply irresistible";

    public static CursorPositionedInReference eat() {
        System.out.println("Refactoring is " + VISUALAGE_FOR_COBOL);
    }
}
