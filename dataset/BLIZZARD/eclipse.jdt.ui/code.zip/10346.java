package p;

public interface A {
}
