import java.util.List;

public class A_testParametricTypeWithNonParametricSuperType_in {

    void foo() {
        Object x = null;
    }
}
