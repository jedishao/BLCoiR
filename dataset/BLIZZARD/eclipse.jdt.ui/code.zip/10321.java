package p;

class A {

    void m() {
        int i = f;
    }

    int f;
}

class B extends A {
}
