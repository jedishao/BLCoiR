import java.util.Arrays;
import java.util.List;
import java.util.Vector;

public class A_testParametricLocalVar_in {

    String fValue2 = "Eclipse";

    List<String> fValue = Arrays.asList("Eclipse");

    String test(String arg) {
        return null;
    }

    List<String> test2(java.util.List<Object> aList, List<Object> l) {
        return null;
    }

    Vector foo(BBB aaa) {
        List<String> xx = null;
        return null;
    }
}

class AAA {
}

class BBB extends AAA {
}
