package p;

class Inner {

    /** Comment */
    private A a;

     Inner(A a) {
        this.a = a;
    }
}
