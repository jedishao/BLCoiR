package p;

class A {

    void m() {
        final int a = 3;
        final int b = 3;
        final int b = 3;
        final int b = 3;
    }
}
