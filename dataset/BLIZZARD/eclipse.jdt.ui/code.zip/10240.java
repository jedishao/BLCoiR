package p;

class A {

    class T {
    }

    void f() {
    }

    {
    }

    int fg;

    static {
    }

    /**
	 * 
	 */
    void f1() {
    }
}
