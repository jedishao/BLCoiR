package p;

class A<T> {

    public void m() {
    }
}

class B extends A<String> {
}
