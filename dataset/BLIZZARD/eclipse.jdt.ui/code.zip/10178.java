package p;

class A {

    public int f;

    public String g;
}
