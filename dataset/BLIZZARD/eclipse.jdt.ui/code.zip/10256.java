//  4, 28 -> 4, 37
class EndsOnSameLine {

    void m() {
        System.out.println(CONSTANT);
    }

    static final String FOO = "foo";

    // $NON-NLS-1$
    private static final String CONSTANT = FOO + FOO;
}
