//renaming A.m to k 
package p;

class A {

    public void k() {
    }
}

class AQE extends A {

    public void k() {
        super.k();
    }
}
