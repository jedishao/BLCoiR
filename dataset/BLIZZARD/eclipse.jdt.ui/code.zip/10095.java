package simple_in;

public class TestEmptyBody {

    public void main() {
        /*]*/
        /*[*/
        foo();
    }

    public void foo() {
    }
}
