package p3;

import p1.A;
import p2.B;

class C {

    {
        A a = new A();
        a.m1A(new B());
    }
}
