package p;

public class A {

    enum Replacer2 implements  {

        NILL1(".class") {
        }
        , NILL2(".class") {
        }
        ;

        String s;

         Replacer2(String s) {
            this.s = s;
        }
    }
}
