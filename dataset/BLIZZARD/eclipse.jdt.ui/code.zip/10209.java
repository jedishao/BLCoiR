package p;

class C {

    void foo() {
    }
}

class D {
}
