package p0;

public class Foo {

    // Test adjustment of target method and target type 
    // because of the intermediary
    public // <- create indirection in p1.Bar
    void hello() {
    }
}
