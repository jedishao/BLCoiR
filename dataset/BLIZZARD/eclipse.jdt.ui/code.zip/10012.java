//renaming I.m to k
package p;

interface I {

    void k();
}

class Test {

    void k() {
    }
}

class C implements I {

    public void k() {
    }

    ;
}
