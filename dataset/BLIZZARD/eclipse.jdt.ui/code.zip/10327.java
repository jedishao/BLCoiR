package p;

/** typecomment template*/
public interface I {

    void x();

    //	 TestRunListener implementation
    void y();

    // xx
    void z();

    /** Javadoc*/
    void a();

    /**JD*/
    //abstract
    void b();

    //destruct
    void c();

    //post
    void d();
}
