package p;

class A {

     A(A a0) {
    }
}

class B extends A {

     B(A a1) {
        super(a1);
    }
}
