//no ref update
package p1;

class A {

    r.A d;
}
