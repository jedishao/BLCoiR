package p;

class A {

    void m(int i) {
        int x = 0;
    }
}
