package p;

class A {

    static int length = 17;

    int[] B = new int[1];

    int m() {
        return A.length;
    }
}
