package p;

class A {

    static class X {
    }

    class Inner {

        void f() {
            X x = new X();
        }
    }
}
