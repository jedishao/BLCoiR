//7, 17 -> 7, 18
package p;

class A {

    private void foo() {
        int s = 0;
        int temp = s;
        int z = -temp;
    }
}
