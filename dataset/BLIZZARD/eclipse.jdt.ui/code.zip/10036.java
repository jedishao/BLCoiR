package static_ref_out;

public class StaticImportNoReference {

    public void foo() {
    }
}
