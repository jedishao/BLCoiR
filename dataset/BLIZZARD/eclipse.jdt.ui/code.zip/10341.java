package p;

public class A {

    Second s;

    Second s2;

    public void print() {
        s.print();
    }
}
