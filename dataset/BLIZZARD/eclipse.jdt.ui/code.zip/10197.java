package p;

class A {

     A(int i) {
    }

    void f() {
        new A(1) {
        };
    }
}
