package p;

/** typecomment template*/
interface I {
}
