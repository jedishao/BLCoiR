package p;

public interface A {

    static void m();
}
