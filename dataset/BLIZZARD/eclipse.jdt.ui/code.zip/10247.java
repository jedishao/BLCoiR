//selection: 7, 28, 7, 45
//name: string -> name
package simple.out;

public class ConstantString {

    void bar(String name) {
        System.out.println(name);
    }

    void use() {
        bar("Charlie Chaplin");
    }
}
