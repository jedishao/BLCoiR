//5, 20 -> 5, 27   AllowLoadtime == false
package p;

class A {

    void f() {
        int i = 1 - (2 + 3);
    }
}
