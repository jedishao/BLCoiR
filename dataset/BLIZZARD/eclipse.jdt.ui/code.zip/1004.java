package p;

public class A1 extends A {

    protected void f(A a) {
        a.m1();
    }
}
