package test1;

public class TestTarget {

    public void methodToMove() {
    }
}
