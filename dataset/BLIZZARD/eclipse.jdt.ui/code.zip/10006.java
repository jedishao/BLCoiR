package p;

class B {
}
