/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.camel.spring.config;

import org.apache.camel.CamelContext;
import org.apache.camel.ThreadPoolRejectedPolicy;
import org.apache.camel.spi.ThreadPoolProfile;
import org.apache.camel.spring.SpringTestSupport;
import org.springframework.context.support.AbstractXmlApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringCamelContextSimpleCustomDefaultThreadPoolProfileTest extends SpringTestSupport {

    protected AbstractXmlApplicationContext createApplicationContext() {
        return new ClassPathXmlApplicationContext("org/apache/camel/spring/config/SpringCamelContextSimpleCustomDefaultThreadPoolProfileTest.xml");
    }

    public void testDefaultThreadPoolProfile() throws Exception {
        CamelContext context = getMandatoryBean(CamelContext.class, "camel-B");

        ThreadPoolProfile profile = context.getExecutorServiceManager().getDefaultThreadPoolProfile();
        assertEquals(25, profile.getMaxPoolSize().intValue());

        // should inherit default values
        assertEquals(10, profile.getPoolSize().intValue());
        assertEquals(60, profile.getKeepAliveTime().longValue());
        assertEquals(1000, profile.getMaxQueueSize().intValue());
        assertEquals(ThreadPoolRejectedPolicy.CallerRuns, profile.getRejectedPolicy());
    }

}